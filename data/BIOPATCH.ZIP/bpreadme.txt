This patch is helpful in getting Bio Menace working in conjunction with DOSBox.

It should be run before starting biomenace inside dosbox. (each time)
(so in dosbox:
biopatch
menace
)

Please be aware that this program comes from the DOSBox team, and not Apogee.

Please visit http://dosbox.sourceforge.net for further information on DOSBox, which is recommended for use with Bio Menace.

-- Apogee Tech Support - Dec 2005